export PIN_ROOT=/champsim/pin_v3.17/
mkdir -p obj-intel64
make obj-intel64/champsim_tracer.so
