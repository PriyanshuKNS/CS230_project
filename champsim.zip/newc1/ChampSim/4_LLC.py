import os
import shutil

traces = ["cadical-high-60K-1227B.champsimtrace.xz", "cadical-high-60K-134B.champsimtrace.xz", "kissat-inc-high-30K-1802B.champsimtrace.xz" ]

def make_output(cache_type, list_of_changes, list_of_repl):
	for repl in list_of_repl:
		for change in list_of_changes:
			with open("./inc/cache.h", "r") as fr:
				x = fr.readlines()

			for i in range(len(x)):
				if(x[i].startswith(f"#define {cache_type} ")):
					x[i] = f"#define {cache_type} NUM_CPUS*{change}\n"

			with open("./inc/cache1.h", "w") as fw:
				for i in range(len(x)):
					fw.write(x[i])
						
			os.system("rm ./inc/cache.h")
			os.system("mv ./inc/cache1.h ./inc/cache.h")
			os.system("sleep 1")

			os.system(f"./build_champsim.sh bimodal no no best_offset_prefetcher no {repl} 1")
			os.system("sleep 1")

			for i in range(len(traces)):
				os.system(f"./run_champsim.sh bimodal-no-no-best_offset_prefetcher-no-{repl}-1core 30 50 {traces[i]}")
				os.system("sleep 1")
			
			os.system(f"mkdir mresults/results_50M-{repl}-LLC-{change}-16")
			source_dir = "results_50M"
			dest_dir = f"mresults/results_50M-{repl}-LLC-{change}-16"
			keyword = repl

			# Loop through all files in the source directory
			for filename in os.listdir(source_dir):
				if keyword in filename:
					# If the keyword is in the filename, move the file to the destination directory
					src_file = os.path.join(source_dir, filename)
					dest_file = os.path.join(dest_dir, filename)
					shutil.move(src_file, dest_file)
			
			
cache_typ = "LLC_SET"
initial = 2048

if not os.path.isdir("mresults"):
	os.system("mkdir mresults")

make_output(cache_typ, [1024, 2048, 4096, 8192], ["prob2"])
with open("./inc/cache.h", "r") as fr:
	x = fr.readlines()

for i in range(len(x)):
	if(x[i].startswith(f"#define {cache_typ} ")):
		x[i] = f"#define {cache_typ} NUM_CPUS*{initial}\n"

with open("./inc/cache1.h", "w") as fw:
	for i in range(len(x)):
		fw.write(x[i])

os.system("rm ./inc/cache.h")
os.system("mv ./inc/cache1.h ./inc/cache.h")
os.system("sleep 1")
	
